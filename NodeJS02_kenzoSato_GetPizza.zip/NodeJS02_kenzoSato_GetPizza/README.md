# GetPizza
Atividade proposta pelo professor Luciano Moreira no curso técnico de Desenvolvimento de Sistemas integrado ao Ensino Médio SESI SENAI.
